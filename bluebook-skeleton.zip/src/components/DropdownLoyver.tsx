export default function DropdownLoyver({ formData, setFormData }: any) {
  return (
    <section className="p-4 border border-black dark:border-white rounded-xl">
      <h2 className="font-bold mb-2">Løyver:</h2>
      <p>(Her kommer dropdown og ID/Navn-felter)</p>
    </section>
  );
}
