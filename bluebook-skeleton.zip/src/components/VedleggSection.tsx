export default function VedleggSection({ vedlegg, setVedlegg }: any) {
  return (
    <section className="p-4 border border-black dark:border-white rounded-xl">
      <h2 className="font-bold mb-2">Vedlegg:</h2>
      <p>(Her kommer opplasting av filer)</p>
    </section>
  );
}
