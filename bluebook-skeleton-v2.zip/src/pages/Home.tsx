import { useState } from "react";
import DropdownLoyver from "../components/DropdownLoyver";
import DateTimeSection from "../components/DateTimeSection";
import TurinfoSection from "../components/TurinfoSection";
import KostnaderSection from "../components/KostnaderSection";
import VedleggSection from "../components/VedleggSection";
import PdfButtons from "../components/PdfButtons";

export default function Home() {
  const [formData, setFormData] = useState<any>({});
  const [kostnader, setKostnader] = useState<any[]>([]);
  const [vedlegg, setVedlegg] = useState<File[]>([]);

  return (
    <div className="max-w-6xl mx-auto p-4 space-y-4">
      <header className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold">Digital Blåbok</h1>
          <p className="text-sm text-gray-500 dark:text-gray-400">
            Alle raude felt MÅ fyllast ut
          </p>
        </div>
        <div className="space-x-2">
          <button className="px-3 py-1 rounded bg-gray-200 dark:bg-gray-700">
            Nullstill
          </button>
          <button className="px-3 py-1 rounded bg-gray-200 dark:bg-gray-700">
            Tema
          </button>
        </div>
      </header>

      <DropdownLoyver formData={formData} setFormData={setFormData} />
      <DateTimeSection formData={formData} setFormData={setFormData} />
      <TurinfoSection formData={formData} setFormData={setFormData} />
      <KostnaderSection kostnader={kostnader} setKostnader={setKostnader} />
      <VedleggSection vedlegg={vedlegg} setVedlegg={setVedlegg} />
      <PdfButtons />
    </div>
  );
}
