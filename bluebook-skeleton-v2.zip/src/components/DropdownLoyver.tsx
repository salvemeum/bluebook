import { useEffect, useMemo, useRef, useState } from "react";
import { capitalizeName } from "../utils/format";

type LoyveEntry = {
  loyve: string;
  sjoforId: string;
  sjoforNavn: string;
};

interface Props {
  formData: { [k: string]: any };
  setFormData: (data: any) => void;
}

export default function DropdownLoyver({ formData, setFormData }: Props) {
  const [biler, setBiler] = useState<string[]>([]);
  const [open, setOpen] = useState(false);

  // Presenter selection as array of objects in formData.loyver
  const selected: LoyveEntry[] = useMemo(
    () => (Array.isArray(formData?.loyver) ? formData.loyver : []),
    [formData?.loyver]
  );

  // Load biler.txt from public/
  useEffect(() => {
    fetch("/biler.txt")
      .then((res) => res.text())
      .then((text) => {
        const lines = text
          .split("\n")
          .map((l) => l.trim())
          .filter(Boolean);
        setBiler(lines);
      })
      .catch(() => setBiler([]));
  }, []);

  // Toggle selection when a checkbox is tapped
  function toggleLoyve(loyve: string) {
    const exists = selected.find((s) => s.loyve === loyve);
    let next: LoyveEntry[];
    if (exists) {
      next = selected.filter((s) => s.loyve !== loyve);
    } else {
      next = [...selected, { loyve, sjoforId: "", sjoforNavn: "" }];
    }
    setFormData({ ...formData, loyver: next });
  }

  function updateLoyveField(loyve: string, field: "sjoforId" | "sjoforNavn", value: string) {
    const next = selected.map((s) => {
      if (s.loyve !== loyve) return s;
      if (field === "sjoforNavn") {
        return { ...s, sjoforNavn: value };
      }
      return { ...s, sjoforId: value };
    });
    setFormData({ ...formData, loyver: next });
  }

  function onBlurFormatName(loyve: string) {
    const item = selected.find((s) => s.loyve === loyve);
    if (!item) return;
    const formatted = capitalizeName(item.sjoforNavn || "");
    if (formatted !== item.sjoforNavn) {
      updateLoyveField(loyve, "sjoforNavn", formatted);
    }
  }

  // Close on outside click
  const wrapperRef = useRef<HTMLDivElement | null>(null);
  useEffect(() => {
    function handleClickOutside(e: MouseEvent) {
      if (wrapperRef.current && !wrapperRef.current.contains(e.target as Node)) {
        setOpen(false);
      }
    }
    if (open) document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, [open]);

  // Button label
  const buttonLabel = useMemo(() => {
    if (selected.length === 0) return "Velg Løyve";
    if (selected.length === 1) return selected[0].loyve;
    if (selected.length <= 3) return selected.map((s) => s.loyve).join(", ");
    return `${selected.length} valgte`;
  }, [selected]);

  return (
    <section className="p-4 border-2 border-black dark:border-white rounded-xl">
      <h2 className="font-bold mb-2">Løyver:</h2>

      <div className="relative" ref={wrapperRef}>
        <button
          type="button"
          onClick={() => setOpen((o) => !o)}
          className="px-4 py-2 rounded bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100 w-full text-left border-2 border-primary shadow-sm focus:outline-none focus:ring-2 focus:ring-primary"
          aria-haspopup="listbox"
          aria-expanded={open}
        >
          {buttonLabel}
        </button>

        {open && (
          <div
            className="absolute z-20 mt-2 w-full rounded-lg border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-800 shadow-xl"
            role="listbox"
            aria-label="Velg løyver"
          >
            {/* Max 6 synlige rader → scroll for resten */}
            <ul className="max-h-60 overflow-y-auto py-1">
              {biler.map((loyve) => {
                const checked = !!selected.find((s) => s.loyve === loyve);
                return (
                  <li key={loyve}>
                    <label className="flex items-center gap-3 px-3 py-2 hover:bg-gray-100 dark:hover:bg-gray-700 cursor-pointer">
                      <input
                        type="checkbox"
                        className="h-5 w-5 accent-red-600"
                        checked={checked}
                        onChange={() => toggleLoyve(loyve)}
                      />
                      <span className="text-sm">{loyve}</span>
                    </label>
                  </li>
                );
              })}
              {biler.length === 0 && (
                <li className="px-3 py-2 text-sm text-gray-500 dark:text-gray-400">
                  Fant ingen løyver i <code>biler.txt</code>
                </li>
              )}
            </ul>
          </div>
        )}
      </div>

      {/* Valgte løyver med ID + Navn */}
      <div className="mt-4 space-y-2">
        {selected.map((item) => (
          <div key={item.loyve} className="flex flex-wrap items-center gap-3">
            <span className="min-w-[5rem] font-semibold">{item.loyve}</span>

            <label className="flex items-center gap-2">
              <span>ID:</span>
              <input
                type="text"
                maxLength={6}
                value={item.sjoforId}
                onChange={(e) => updateLoyveField(item.loyve, "sjoforId", e.target.value)}
                className="border-2 border-primary rounded px-2 py-1 w-24 bg-white dark:bg-gray-700"
              />
            </label>

            <label className="flex items-center gap-2">
              <span>Navn:</span>
              <input
                type="text"
                maxLength={35}
                value={item.sjoforNavn}
                onChange={(e) => updateLoyveField(item.loyve, "sjoforNavn", e.target.value)}
                onBlur={() => onBlurFormatName(item.loyve)}
                className="border-2 border-primary rounded px-2 py-1 w-72 max-w-full bg-white dark:bg-gray-700"
              />
            </label>
          </div>
        ))}
      </div>
    </section>
  );
}
