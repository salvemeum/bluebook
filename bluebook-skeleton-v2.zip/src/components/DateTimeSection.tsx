export default function DateTimeSection({ formData, setFormData }: any) {
  return (
    <section className="p-4 border border-black dark:border-white rounded-xl">
      <h2 className="font-bold mb-2">Dato og Tid:</h2>
      <p>(Her kommer dato, start, slutt)</p>
    </section>
  );
}
