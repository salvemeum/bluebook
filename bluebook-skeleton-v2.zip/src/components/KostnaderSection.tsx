export default function KostnaderSection({ kostnader, setKostnader }: any) {
  return (
    <section className="p-4 border border-black dark:border-white rounded-xl">
      <h2 className="font-bold mb-2">Kostnader:</h2>
      <p>(Her kommer feltene Turpris, Venting, osv)</p>
    </section>
  );
}
